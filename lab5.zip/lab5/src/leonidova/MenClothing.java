package leonidova;

public interface MenClothing {
    void dressMan();
}
