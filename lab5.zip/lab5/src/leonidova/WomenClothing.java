package leonidova;

public interface WomenClothing {
    void dressWoman();
}
